//
//  ViewControllerOrder.swift
//  demo9
//
//  Created by TS00202 on 2020/3/16.
//  Copyright © 2020 babyworkshop. All rights reserved.
//

import UIKit

class ViewControllerOrder: UIViewController {
    
    @IBOutlet weak var myTextView: UITextView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnClearOrderList: UIButton!
    
    // 宣告AppDelegate裡面建立的單例2
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    // 作業規格：計算總價
    var int加料數量1: Int = 0
    var int加料數量2: Int = 0
    var int加料數量3: Int = 0
    var int總價: Int = 0
    
    // 回到上一頁按鈕
        // vs.開啟視圖：self.present
        // 關閉新視圖控制器：self.dismiss
            // animated過場動畫是否開啟()
                // 動畫種類可在Segue的Transition修改
            // 沒有要同時執行的動作，閉包打nil
    @IBAction func btnBack_Click(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    // 清空訂購單按鈕
    @IBAction func btnClearOrderList_Click(_ sender: Any) {
        appDelegate.arrayOrderList.removeAll()
        self.myTextView.text = ""
        self.int總價 = 0
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        print(appDelegate.arrayOrderList)
        
        self.myTextView.text = "＝＝＝歡迎購買·寶寶工坊飲品＝＝＝"
        
        // 作業規格：時間
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            // 改中文
        let myLocale = Locale(identifier: "zh_TW")
        dateFormatter.locale = myLocale

        let nowDate = Date()
        var myDateString: String = dateFormatter.string(from: nowDate)

        if appDelegate.arrayOrderList.count > 0
        {
            var str品名 = ""
            var str冰量 = ""
            var str甜度 = ""
            var int價格 = 0
            var int杯數 = 0
            
            var str加料1 = ""
            var str加料2 = ""
            var str加料3 = ""
            
            int加料數量1 = 0
            int加料數量2 = 0
            int加料數量3 = 0
            int總價 = 0
            
            for myItem in appDelegate.arrayOrderList
            {
                str品名 = myItem["品名"] as! String
                str冰量 = myItem["冰量"] as! String
                str甜度 = myItem["甜度"] as! String
                int價格 = myItem["價格"] as! Int
                int杯數 = myItem["杯數"] as! Int
                
                str加料1 = myItem["加料1"] as! String
                str加料2 = myItem["加料2"] as! String
                str加料3 = myItem["加料3"] as! String
                
                if str加料1 != ""
                {
                    int加料數量1 = 1
                }
                if str加料2 != ""
                {
                    int加料數量2 = 1
                }
                if str加料3 != ""
                {
                    int加料數量3 = 1
                }
                
                int總價 += (int價格 + int加料數量1 * 10 + int加料數量2 * 10 + int加料數量3 * 10) * int杯數
                    
                self.myTextView.text += "\(str品名) (\(int價格)元) \(int杯數)杯\n\(str冰量)  \(str甜度)\n加料：\(str加料1) \(str加料2) \(str加料3)\n\n"
            }
            self.myTextView.text += "飲品總價：$\(int總價)元"
            self.myTextView.text += "\n訂購時間為：\(myDateString)"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
