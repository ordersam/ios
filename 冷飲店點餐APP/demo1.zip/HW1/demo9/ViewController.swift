//
//  ViewController.swift
//  demo9
//
//  Created by TS00202 on 2020/3/10.
//  Copyright © 2020 babyworkshop. All rights reserved.
//

import UIKit
// 實作Delegate 1：UIPickerViewDelegate, UIPickerViewDataSource
class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var myPickerView1: UIPickerView!
    @IBOutlet weak var myPickerView2: UIPickerView!
    @IBOutlet weak var lblDrinkOrder: UILabel!
    @IBOutlet weak var stpCups: UIStepper!
    @IBOutlet weak var imgDrink: UIImageView!
    @IBOutlet weak var btnAddDrink: UIButton!
    
    // 屬性:陣列儲存產品名稱.單價.冰.甜度.圖檔名稱
    var arrayDrinks: [String] = [String]()
    var arrayPrices: [Int] = [Int]()
    var arrayIce: [String] = [String]()
    var arraySugar: [String] = [String]()
    var arrayDrinkFiles: [String] = [String]()
    
    var arrayAdd1: [String] = [String]()
    var arrayAdd2: [String] = [String]()
    var arrayAdd3: [String] = [String]()
    
    // 訂購內容
    var str品名 = ""
    var str冰量 = ""
    var str甜度 = ""
    var int價格 = 0
    var int杯數 = 0
    
    var str加料1 = ""
    var str加料2 = ""
    var str加料3 = ""
    
    // 宣告AppDelegate裡面建立的單例1
        // cast：將已知型別告知編譯器(已知型別用as)
        // 保證單例不為空值
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    // 使用單例：加入購物車：每次點選就會加入全域變數
    @IBAction func btnAddDrink_Click(_ sender: Any) {
        let dictorder: [String:Any] = ["品名":str品名, "冰量":str冰量, "甜度":str甜度, "價格":int價格, "杯數":int杯數, "加料1":str加料1, "加料2":str加料2, "加料3":str加料3]
        appDelegate.arrayOrderList.append(dictorder)
    }
    
    // 杯數變動：Stepper最小1杯，最大99杯
    @IBAction func stpCups_ValueChanged(_ sender: Any) {
        
        int杯數 = Int(stpCups.value)
        let strDrinkOrder = "---訂購內容---\n\(str品名) (\(int價格)元) \(int杯數)杯\n\(str冰量)  \(str甜度)\n加料：\(str加料1) \(str加料2) \(str加料3) "
        lblDrinkOrder.text = strDrinkOrder
    }
    
    // 實作Delegate 3：PickerView Delegate Protocol
        // 產生幾個滾輪
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        if pickerView.tag == 101
        {
            return 3
        }
        else
        {
            return 3
        }
    }
        // numberOfRowsInComponent：每個滾輪有幾筆資料
            // 用component判斷是哪個滾輪index(飲料名稱.冰.糖)
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var numRows = 0
        
        if pickerView.tag == 101
        {
            if component == 0
            {
                numRows = arrayDrinks.count
            }
            else if component == 1
            {
                numRows = arrayIce.count
            }
            else if component == 2
            {
                numRows = arraySugar.count
            }
        }
        else
        {
            if component == 0
            {
                numRows = arrayAdd1.count
            }
            else if component == 1
            {
                numRows = arrayAdd2.count
            }
            else if component == 2
            {
                numRows = arrayAdd3.count
            }
        }
        return numRows
    }
        // titleForRow：每個row的文字描述
            // 傳入 滾輪 跟 row 的index
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        var rowTitle = ""
        if pickerView.tag == 101
        {
            if component == 0
            {
                rowTitle = arrayDrinks[row]
            }
            else if component == 1
            {
                rowTitle = arrayIce[row]
            }
            else if component == 2
            {
                rowTitle = arraySugar[row]
            }
        }
        else
        {
            if component == 0
            {
                rowTitle = arrayAdd1[row]
            }
            else if component == 1
            {
                rowTitle = arrayAdd2[row]
            }
            else if component == 2
            {
                rowTitle = arrayAdd3[row]
            }
        }
        return rowTitle
    }
    
    // 停下來就會觸發(已經選到某項目)
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        var strDrinkOrder = ""
        if pickerView.tag == 101
        {
            if component == 0
            {
                str品名 = arrayDrinks[row]
                int價格 = arrayPrices[row]
                imgDrink.image = UIImage(named: arrayDrinkFiles[row])
            }
            else if component == 1
            {
                str冰量 = arrayIce[row]
            }
            else if component == 2
            {
                str甜度 = arraySugar[row]
            }
            strDrinkOrder = "---訂購內容---\n\(str品名) (\(int價格)元) \(int杯數)杯\n\(str冰量)  \(str甜度)\n加料：\(str加料1) \(str加料2) \(str加料3)"
        }
        else
        {
            if component == 0
            {
                str加料1 = arrayAdd1[row]
            }
            else if component == 1
            {
                str加料2 = arrayAdd2[row]
            }
            else if component == 2
            {
                str加料3 = arrayAdd3[row]
            }
            strDrinkOrder = "---訂購內容---\n\(str品名) (\(int價格)元) \(int杯數)杯\n\(str冰量)  \(str甜度)\n加料：\(str加料1) \(str加料2) \(str加料3)"
        }
        
        lblDrinkOrder.text = strDrinkOrder
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 初始化(預設值)
        arrayDrinks = ["紅茶", "綠茶", "奶茶", "麥茶", "青茶", "花茶", "水果茶", "可可", "咖啡", "豆漿"]
        arrayPrices = [20, 20, 35, 15, 25, 25, 50, 40, 60, 30]
        arrayIce = ["正常冰", "半冰", "少冰", "微冰", "去冰", "溫", "熱"]
        arraySugar = ["正常甜", "半糖", "少糖", "微糖", "無糖"]
        arrayDrinkFiles = ["red.jpg", "green.jpg", "奶茶.jpg", "麥茶.jpg", "青茶.jpg", "6花茶.jpg", "7水果茶.jpg", "8可可.jpg", "9咖啡.jpg", "10豆漿.jpg"]
        
        arrayAdd1 = ["", "珍珠", "波霸", "仙草", "椰果", "粉條"]
        arrayAdd2 = ["", "珍珠", "波霸", "仙草", "椰果", "粉條"]
        arrayAdd3 = ["", "珍珠", "波霸", "仙草", "椰果", "粉條"]
        
        str品名 = arrayDrinks[0]
        int價格 = arrayPrices[0]
        str冰量 = arrayIce[0]
        str甜度 = arraySugar[0]
        int杯數 = 1
        
        str加料1 = arrayAdd1[0]
        str加料2 = arrayAdd2[0]
        str加料3 = arrayAdd3[0]
        
        let strDrinkOrder = "---訂購內容---\n\(str品名) (\(int價格)元) \(int杯數)杯\n\(str冰量)  \(str甜度)\n加料：\(str加料1) \(str加料2) \(str加料3) "
        lblDrinkOrder.text = strDrinkOrder
        
        // 動態指定圖檔
        imgDrink.image = UIImage(named: arrayDrinkFiles[0])
        
        // 實作Delegate 2
        myPickerView1.delegate = self
        myPickerView1.dataSource = self
        
        myPickerView2.delegate = self
        myPickerView2.dataSource = self
    }
}
