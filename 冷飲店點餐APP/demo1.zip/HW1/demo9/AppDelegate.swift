//
//  AppDelegate.swift
//  demo9
//
//  Created by TS00202 on 2020/3/10.
//  Copyright © 2020 babyworkshop. All rights reserved.
//

import UIKit

@UIApplicationMain
// AppDelegate為單例
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    // 使用單例：全域變數：字典陣列，value型別為Any表示任意型別
        // 如果是AnyObject只能存放參考物件
    var arrayOrderList:[[String:Any]] = [[String:Any]]()
    
    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

