//
//  ViewControllerOrder.swift
//  demo9
//
//  Created by TS00202 on 2020/3/25.
//  Copyright © 2020 babyworkshop. All rights reserved.
//

import UIKit

class ViewControllerOrder: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var myTableView: UITableView!
    
    @IBOutlet weak var btnEdit: UIBarButtonItem!
    @IBOutlet weak var btnClear: UIBarButtonItem!
    @IBOutlet weak var btnFavorite: UIBarButtonItem!
    
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    // 作業規格：計算總價
    var int總價: Int = 0
    
    // 單例
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    // 實作table view delegate protocol
        // 類似PickerView，可將訂購單 單一品項 刪除
        // 1.幾個資料群組(section) numberOfSections
    func numberOfSections(in tableView: UITableView) -> Int {
        int總價 = 0
        return 1
    }
        // 2.每個資料群組各有多少資料 numberOfRowsInSection
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rowNum: Int = 0
        rowNum = appDelegate.arrayOrderList.count
        return rowNum
    }
        // 3.每個儲存格 各為何內容 cellForRowAt
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            // 儲存格名稱：屬性 identifier 填入的名稱
        let cellID = "cell"
            // 利用儲存格的原型UITableViewCell 實作儲存格
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: cellID)
            // 因為可為空值，需要條件判斷
                // 建一個新的儲存格，這樣就不會有空值儲存格存在
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: cellID)
        }
            // 依照群組(section) 顯示儲存格 標題 和 內容
                // indexPath 包含 section 和 row
                // 依照群組改 backgroundColor
                // 依照群組改 圖片
        if appDelegate.arrayOrderList.count != 0
        {
            cell?.contentView.backgroundColor =  #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
            
            let str品名 = appDelegate.arrayOrderList[indexPath.row]["品名"] as! String
            let int價格 = appDelegate.arrayOrderList[indexPath.row]["價格"] as! Int
            cell?.textLabel?.text = "\(str品名) (\(int價格)元)"
            
            let str冰量 = appDelegate.arrayOrderList[indexPath.row]["冰量"] as! String
            let str甜度 = appDelegate.arrayOrderList[indexPath.row]["甜度"] as! String
            let int杯數 = appDelegate.arrayOrderList[indexPath.row]["杯數"] as! Int
            let str加料1 = appDelegate.arrayOrderList[indexPath.row]["加料1"] as! String
            let str加料2 = appDelegate.arrayOrderList[indexPath.row]["加料2"] as! String
            let str加料3 = appDelegate.arrayOrderList[indexPath.row]["加料3"] as! String
            let int加料 = appDelegate.arrayOrderList[indexPath.row]["加料"] as! Int
            cell?.detailTextLabel?.text = "\(int杯數)杯 \(str冰量)  \(str甜度) 加料：\(str加料1) \(str加料2) \(str加料3)"
            cell?.imageView?.image = UIImage(named: "drinklogo.png")
            
            
            // 結帳金額
            int總價 += (int價格 + int加料*10) * int杯數
            lblCount.text = "結帳金額：\(int總價)元"
        }
        // 只要空值就會補一個新的儲存格，儲存格不會是空值
        return cell!
    }
    
    // 刪除資料：觸控手勢由右向左滑可按delete刪除
        // canEditRowAt 改true，表示在可編輯模式下
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
        // 編輯模式 UITableViewCell.EditingStyle
            // indexPath 包含 section 和 row
                // section 為哪一個群組索引值
                // row 為群組內的資料索引值
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        // 編輯模式：如果按 儲存格刪除
        if editingStyle == UITableViewCell.EditingStyle.delete
        {
            // 移除指定(index)儲存格
            appDelegate.arrayOrderList.remove(at: indexPath.row)
            
            // 刪除之後重新載入資料，才會顯示變更過後內容
            tableView.reloadData()
        }
    }
    
    // 編輯模式(可移動)
        // 可移動：canMoveRowAt 改true
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
        // moveRowAt
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        // 複製 > 刪除原資料 > 移動到新位置
        let item = appDelegate.arrayOrderList[sourceIndexPath.row]
        appDelegate.arrayOrderList.remove(at: sourceIndexPath.row)
        appDelegate.arrayOrderList.insert(item, at: destinationIndexPath.row)
        
        // 移動後要重新載入資料，才會顯示變更過後內容
        tableView.reloadData()
    }

    
    // 左上角 編輯按鈕：編輯模式可以刪除資料、改變資料排序...
        // 同一個按鈕是 進入編輯模式，也是 結束編輯模式
    @IBAction func btnEdit_Click(_ sender: Any) {
        // (2)如果在編輯模式(模式狀態 為 正在編輯)
            // 按下去會退出編輯模式
            // 模式狀態 改為 沒有在編輯(setEditing為false)
            // title變回編輯
        if myTableView.isEditing == true
        {
            myTableView.setEditing(false, animated: true)
            btnEdit.title = "編輯"
        }
        // (1)一開始進入並非編輯模式
            // 按下去會進入編輯模式
            // 模式狀態 改為 正在編輯(setEditing為true)
            // title為完成
        else
        {
            myTableView.setEditing(true, animated: true)
            btnEdit.title = "完成"
        }
    }
    
    
    // 清空購物車
    @IBAction func btnClear_Click(_ sender: Any) {
        appDelegate.arrayOrderList.removeAll()
        self.lblCount.text = "結帳金額：0元"
        // 重新載入tableView
        myTableView.reloadData()
    }
    
    
    // UserDefaults 寫入檔案內容
    let myUserDefaults: UserDefaults = UserDefaults.standard
    // 加入我的最愛
    @IBAction func btnFavorite_Click(_ sender: Any) {
        myUserDefaults.set(appDelegate.arrayOrderList, forKey: "Favorite")
        appDelegate.arrayOrderFavorite = myUserDefaults.value(forKey: "Favorite") as! [[String: Any]]
        // 有我的最愛，變顏色
        if appDelegate.arrayOrderFavorite.count != 0
        {
            btnFavorite.tintColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        }
        else
        {
            btnFavorite.tintColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // 實作Delegate 2
        self.myTableView.delegate = self
        self.myTableView.dataSource = self
        
        int總價 = 0
        self.lblCount.text = "結帳金額：0元"
        
        // 作業規格：時間
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let nowDate = Date()
        let myDateString: String = dateFormatter.string(from: nowDate)
        self.lblTime.text = "訂購時間：\(myDateString)"
        
        // 有我的最愛，變顏色
        if appDelegate.arrayOrderFavorite.count != 0
        {
            btnFavorite.tintColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        }
        else
        {
            btnFavorite.tintColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        }  
    }
}
